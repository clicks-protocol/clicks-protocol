"use client";

import Link from 'next/link';
import { FileText, ArrowRight } from 'lucide-react';

export default function WhitepaperPage() {
  return (
    <div className="prose-docs">
      <h1 className="text-3xl sm:text-4xl font-bold mb-6 gradient-text">Whitepaper</h1>

      <div className="glassmorphism rounded-xl p-8 text-center max-w-lg mx-auto mt-12">
        <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-6">
          <FileText className="w-8 h-8 text-accent" />
        </div>
        <h2 className="text-xl font-bold mb-3 text-text-primary">Coming Soon</h2>
        <p className="text-text-secondary leading-relaxed mb-6">
          Detailed technical documentation is in progress. For now, see the About page for protocol overview and the SDK Reference for integration details.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/docs/about"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-accent/10 text-accent hover:bg-accent/20 transition-colors text-sm font-medium"
          >
            About <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            href="/docs/api"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-white/10 text-text-primary hover:bg-white/5 transition-colors text-sm font-medium"
          >
            SDK Reference <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
