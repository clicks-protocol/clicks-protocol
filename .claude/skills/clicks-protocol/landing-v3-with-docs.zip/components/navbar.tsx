"use client";

import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react';

export function Navbar() {
  return (
    <nav className="fixed top-0 w-full z-50 border-b border-border glassmorphism">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-3 flex-1">
            <img
              src="/logo.svg"
              alt="Clicks"
              className="h-8 sm:h-9 lg:h-10 w-auto"
            />
          </div>
          <div className="hidden md:flex items-center justify-center space-x-8 flex-1">
            <a
              href="#how-it-works"
              className="text-text-secondary hover:text-text-primary transition-colors"
            >
              How it Works
            </a>
            <a
              href="#developers"
              className="text-text-secondary hover:text-text-primary transition-colors"
            >
              Developers
            </a>
          </div>
          <div className="hidden md:flex items-center justify-end space-x-6 flex-1">
            <a
              href="https://github.com/clicks-protocol"
              target="_blank"
              rel="noopener noreferrer"
              className="text-text-secondary hover:text-text-primary transition-colors"
            >
              GitHub
            </a>
            <a
              href="https://discord.gg/clicks-protocol"
              target="_blank"
              rel="noopener noreferrer"
              className="text-text-secondary hover:text-text-primary transition-colors"
            >
              Discord
            </a>
            <Button size="sm">Get Started</Button>
          </div>
          <button className="md:hidden">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>
    </nav>
  );
}
